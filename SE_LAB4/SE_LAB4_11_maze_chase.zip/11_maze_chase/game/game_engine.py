import random
import pygame
from game.maze import generate_maze, build_wall_rects, CELL
from game.entities import Player, Enemy, BASE_INTERVAL

COLS, ROWS = 13, 11
WIDTH = COLS * CELL
HEIGHT = ROWS * CELL + 50
FPS = 60
RAMP_MS = 15000
RAMP_STEP = 2
MIN_INTERVAL = 5
FREEZE_FRAMES = 300

class GameEngine:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Maze Chase")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont("monospace", 22)
        self.small_font = pygame.font.SysFont("monospace", 16)
        self.big_font = pygame.font.SysFont("monospace", 38, bold=True)
        self.reset()

    def reset(self):
        self.walls = generate_maze(COLS, ROWS)
        self.wall_rects = build_wall_rects(self.walls, ROWS, COLS)
        self.player = Player(0, 0)
        self.enemies = [
            Enemy(ROWS-1, COLS-1),
            Enemy(ROWS-1, 0),
            Enemy(0, COLS-1),
        ]
        self.exit_rect = pygame.Rect((COLS//2)*CELL+5, (ROWS//2)*CELL+5, CELL-10, CELL-10)
        self.pellet = self._place_pellet()
        self.freeze_timer = 0
        self.score = 0
        self.start_ticks = pygame.time.get_ticks()
        self.tier = 0
        self.caught = False
        self.won = False

    def _place_pellet(self):
        blocked = {(0,0),(ROWS-1,COLS-1),(ROWS-1,0),(0,COLS-1),(ROWS//2,COLS//2)}
        options = [(r,c) for r in range(ROWS) for c in range(COLS)
                   if (r,c) not in blocked and r+c >= 4]
        r, c = random.choice(options)
        return pygame.Rect(c*CELL+CELL//2-9, r*CELL+CELL//2-9, 18, 18)

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT: return False
            if event.type == pygame.KEYDOWN and event.key == pygame.K_r: self.reset()
        return True

    def _update_difficulty(self):
        elapsed = pygame.time.get_ticks() - self.start_ticks
        self.tier = elapsed // RAMP_MS
        interval = max(MIN_INTERVAL, BASE_INTERVAL - RAMP_STEP * self.tier)
        for e in self.enemies:
            e.move_interval = interval

    def _update_freeze(self):
        if self.freeze_timer > 0:
            self.freeze_timer -= 1
            if self.freeze_timer == 0:
                for e in self.enemies:
                    e.frozen = False

    def update(self):
        if self.caught or self.won: return
        keys = pygame.key.get_pressed()
        self.player.move(keys, self.wall_rects, ROWS, COLS)
        self._update_difficulty()
        self._update_freeze()
        for e in self.enemies:
            e.update(self.walls, self.player, ROWS, COLS)
        if self.pellet and self.player.rect.colliderect(self.pellet):
            self.pellet = None
            self.freeze_timer = FREEZE_FRAMES
            for e in self.enemies:
                e.frozen = True
        for e in self.enemies:
            if self.player.rect.colliderect(e.rect):
                self.caught = True
        if self.player.rect.colliderect(self.exit_rect):
            self.won = True
        if not self.caught and not self.won:
            self.score += 1

    def draw(self):
        self.screen.fill((230, 220, 210))
        wc=(50,40,60)
        for r in range(ROWS):
            for c in range(COLS):
                x,y=c*CELL,r*CELL
                w=self.walls[r][c]
                if w[0]: pygame.draw.line(self.screen,wc,(x,y),(x+CELL,y),3)
                if w[1]: pygame.draw.line(self.screen,wc,(x,y+CELL),(x+CELL,y+CELL),3)
                if w[2]: pygame.draw.line(self.screen,wc,(x+CELL,y),(x+CELL,y+CELL),3)
                if w[3]: pygame.draw.line(self.screen,wc,(x,y),(x,y+CELL),3)
        pygame.draw.rect(self.screen,(80,200,80),self.exit_rect,border_radius=4)
        lbl=self.small_font.render("EXIT",True,(20,80,20))
        self.screen.blit(lbl,(self.exit_rect.centerx-lbl.get_width()//2,self.exit_rect.centery-lbl.get_height()//2))
        if self.pellet:
            pygame.draw.circle(self.screen,(250,210,40),self.pellet.center,self.pellet.width//2)
            pygame.draw.circle(self.screen,(180,140,0),self.pellet.center,self.pellet.width//2,2)
        self.player.draw(self.screen)
        for e in self.enemies:
            e.draw(self.screen)
        self._draw_hud()
        if self.caught:
            self._overlay("CAUGHT!", (220,60,60))
        if self.won:
            self._overlay("ESCAPED!", (80,220,80))
        pygame.display.flip()

    def _draw_hud(self):
        hud=pygame.Rect(0,ROWS*CELL,WIDTH,50)
        pygame.draw.rect(self.screen,(30,30,50),hud)
        speed = max(MIN_INTERVAL, BASE_INTERVAL - RAMP_STEP * self.tier)
        line1 = f"Survived: {self.score//60}s   Speed tier: {self.tier} (every {speed}f)"
        if self.freeze_timer > 0:
            line2 = f"FROZEN {self.freeze_timer/60:.1f}s"
            color2 = (120,200,255)
        else:
            line2 = "Grab the pellet, reach EXIT!  R=Restart"
            color2 = (200,200,200)
        t1=self.small_font.render(line1,True,(220,220,220))
        t2=self.small_font.render(line2,True,color2)
        self.screen.blit(t1,(8,ROWS*CELL+5))
        self.screen.blit(t2,(8,ROWS*CELL+27))

    def _overlay(self, text, color):
        surf=pygame.Surface((WIDTH,ROWS*CELL),pygame.SRCALPHA)
        surf.fill((0,0,0,140))
        self.screen.blit(surf,(0,0))
        msg=self.big_font.render(text,True,color)
        score=self.font.render(f"Final score: {self.score}  ({self.score//60}s)",True,(240,240,240))
        sub=self.font.render("Press R to Restart",True,(200,200,200))
        cy=ROWS*CELL//2
        self.screen.blit(msg,(WIDTH//2-msg.get_width()//2,cy-50))
        self.screen.blit(score,(WIDTH//2-score.get_width()//2,cy))
        self.screen.blit(sub,(WIDTH//2-sub.get_width()//2,cy+30))

    def run(self):
        running=True
        while running:
            running=self.handle_events()
            self.update()
            self.draw()
            self.clock.tick(FPS)
        pygame.quit()

import random
from collections import deque
import pygame

CELL = 44
WALL_T = 4

def generate_maze(cols, rows):
    visited = [[False]*cols for _ in range(rows)]
    walls = [[[True,True,True,True] for _ in range(cols)] for _ in range(rows)]
    def neighbors(r,c):
        dirs=[(-1,0,0,1),(1,0,1,0),(0,1,2,3),(0,-1,3,2)]
        res=[]
        for dr,dc,wd,od in dirs:
            nr,nc=r+dr,c+dc
            if 0<=nr<rows and 0<=nc<cols and not visited[nr][nc]:
                res.append((nr,nc,wd,od))
        return res
    stack=[(0,0)]
    visited[0][0]=True
    while stack:
        r,c=stack[-1]
        nbrs=neighbors(r,c)
        if nbrs:
            nr,nc,wd,od=random.choice(nbrs)
            walls[r][c][wd]=False
            walls[nr][nc][od]=False
            visited[nr][nc]=True
            stack.append((nr,nc))
        else:
            stack.pop()
    return walls

def build_wall_rects(walls, rows, cols):
    rects=[]
    h=WALL_T//2
    for r in range(rows):
        for c in range(cols):
            x,y=c*CELL,r*CELL
            w=walls[r][c]
            if w[0]: rects.append(pygame.Rect(x-h,y-h,CELL+WALL_T,WALL_T))
            if w[1]: rects.append(pygame.Rect(x-h,y+CELL-h,CELL+WALL_T,WALL_T))
            if w[2]: rects.append(pygame.Rect(x+CELL-h,y-h,WALL_T,CELL+WALL_T))
            if w[3]: rects.append(pygame.Rect(x-h,y-h,WALL_T,CELL+WALL_T))
    return rects

def bfs(walls, start, goal, rows, cols):
    sr,sc=start; gr,gc=goal
    queue=deque([(sr,sc,None)])
    visited={(sr,sc)}
    dir_map={0:(-1,0),1:(1,0),2:(0,1),3:(0,-1)}
    while queue:
        r,c,first=queue.popleft()
        if r==gr and c==gc:
            return first
        for d,(dr,dc) in dir_map.items():
            if not walls[r][c][d]:
                nr,nc=r+dr,c+dc
                if (nr,nc) not in visited and 0<=nr<rows and 0<=nc<cols:
                    visited.add((nr,nc))
                    queue.append((nr,nc,first if first else (dr,dc)))
    return None
